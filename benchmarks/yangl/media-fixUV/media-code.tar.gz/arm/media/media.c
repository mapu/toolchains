#include "medias.h"
#include "common.h"
#include "exports.h"

#define SDA0DM0_START 0x400000
#define SDA1DM0_START 0x800000
#define SDA2DM0_START 0xc00000
//int32_t send_vector(uint32_t dst, uint32_t src, uint32_t len, uint32_t size, uint32_t cpuid);
//int32_t ape_dma_wait(uint32_t group, uint32_t cpuid);
//int32_t fetch_vector(uint32_t dst, uint32_t src, uint32_t len, uint32_t size, uint32_t cpuid);

int main(int argc, char * argv[])
{
  short DE_MH[672];
  unsigned char CE_MB[128];
  unsigned short CE_MH[1184];
  int CE_M32[64];
  const int PixelNum = 320*120;
  unsigned short *Src=(unsigned short *)0x72000000;
  unsigned char *Result=(unsigned char *)0x76000000;
  unsigned short *de=(unsigned short *)0x76000000;
  short *ce=(short *)0x76000000;
  int i;

  /* initialze the source data */

  for(i=0;i<32;i++)
  {
    DE_MH[ 0*32+i] =-128;
    DE_MH[ 1*32+i] =-56;
    DE_MH[ 2*32+i] =-176;
    DE_MH[ 3*32+i] =720;
    DE_MH[ 4*32+i] =-176;
    DE_MH[ 5*32+i] =-56;
    DE_MH[ 6*32+i] =-128;
    DE_MH[ 7*32+i] =85;
    DE_MH[ 8*32+i] =0;
    DE_MH[ 9*32+i] =-1;
    DE_MH[10*32+i] =12;
    DE_MH[11*32+i] =8192;
    DE_MH[12*32+i] =8;
    DE_MH[13*32+i] =-256;
    DE_MH[14*32+i] =-256;
    DE_MH[15*32+i] =1024;
    DE_MH[16*32+i] =-256;
    DE_MH[17*32+i] =-256;
    DE_MH[18*32+i] =1023;
    DE_MH[19*32+i] =100;
    DE_MH[20*32+i] =-100;
  }
  for(i=0;i<64;i++)
  {
    CE_MB[0*64+i]=i%2;
    CE_MB[1*64+i]=(i/2)*2;
  }
  for(i=0;i<32;i++)
  {
    CE_MH[0*32+i] =31;
    CE_MH[1056+i] =128;
    CE_MH[1088+i] =2;
    CE_MH[1120+i] =0;
    CE_MH[1152+i] =255;
  }
  for(i=0;i<1024;i++)
  {
    CE_MH[32+i] =i;
  }
  for(i=0;i<16;i++)
  {
    CE_M32[0*16+i] =0x1C501C5;
    CE_M32[1*16+i] =0x580058;
    CE_M32[2*16+i] =182;
    CE_M32[3*16+i] =358;
  }
  
  send_vector(SDA2DM0_START+0x3EB00, (uint32_t)DE_MH, 672, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//DE

  send_vector(SDA2DM0_START+0x3F040, (uint32_t)CE_MB, 128, DT_BYTE, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//CE

  send_vector(SDA2DM0_START+0x3F040+128, (uint32_t)CE_MH, 1184, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//CE

  send_vector(SDA2DM0_START+0x3F040+2496, (uint32_t)CE_M32, 64, DT_WORD, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//CE

  send_vector(SDA2DM0_START+0x3FB00, (uint32_t)0x78000000, 1280, DT_BYTE, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//CC


  send_matrix(SDA0DM0_START, (uint32_t)Src, 326, 124, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//y

  send_matrix(SDA1DM0_START+2560, (uint32_t)(Src+40424), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//u
  send_matrix(SDA1DM0_START+5120, (uint32_t)(Src+78824), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//v

/*
  send_matrix(SDA0DM0_START+2608, (uint32_t)(Src+80848), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//u
  send_matrix(SDA0DM0_START+5168, (uint32_t)(Src+157648), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//v
*/
/*
  send_matrix(SDA1DM0_START, (uint32_t)Src, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//y
  send_matrix(SDA1DM0_START+2560, (uint32_t)(Src+38400), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//u
  send_matrix(SDA1DM0_START+5120, (uint32_t)(Src+76800), 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_E2I_GP, 0);//v
*/
////////////////////////////
  medias(NULL, 0);
  ape_wait(0);
/*
///////////////////////DE
  fetch_matrix((uint32_t)de, SDA1DM0_START, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//Y   
  fetch_matrix((uint32_t)(de+38400), SDA1DM0_START+2560, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//U   
  fetch_matrix((uint32_t)(de+76800), SDA1DM0_START+5120, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//V   
  printf("Output:\n");
  for(i = 0; i < PixelNum; i++)
  {
    printf("%d\t",*(de + i+0));//Y
    printf("%d\t",*(de + i+38400));//U
    printf("%d\t",*(de + i+76800));//V
    printf("\n"); 
  }
*/

/*
///////////////////////CE
  fetch_matrix((uint32_t)ce, SDA0DM0_START, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//R   
  fetch_matrix((uint32_t)(ce+38400), SDA0DM0_START+2560, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//G   
  fetch_matrix((uint32_t)(ce+76800), SDA0DM0_START+5120, 320, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//B   
  printf("Output:\n");
  for(i = 0; i < PixelNum; i++)
//  for(i = 0; i < 32; i++)
  {
    printf("%d\t",*(ce + i+0));//R
    printf("%d\t",*(ce + i+38400));//G
    printf("%d\t",*(ce + i+76800));//B
    printf("\n"); 
  }
*/


////////////CC
  fetch_matrix((uint32_t)Result, SDA1DM0_START, 640, 120, DT_HALF, 0);
  ape_dma_wait(DATA_I2E_GP, 0);//wait DMA to finish  

  printf("Output:\n");
  for(i = 0; i < PixelNum; i++)
  {
   // printf("%d\t",Result1[4*i+3]);
    printf("%d\t",Result[4*i+2]);
    printf("%d\t",Result[4*i+1]);
    printf("%d\n",Result[4*i+0]);
  }


  return 0;
}
