// This is a generated file for MPU library reference
#ifndef MLIB_H
#define MLIB_H

#ifndef MELF_mediam
#define MELF_mediam 0
#endif

#ifndef ID_init_parameter_de
#define ID_init_parameter_de MELF_mediam
#endif

#ifndef ID_demh
#define ID_demh MELF_mediam
#endif

#ifndef ID_demv
#define ID_demv MELF_mediam
#endif

#ifndef ID_cem
#define ID_cem MELF_mediam
#endif

#ifndef ID_ccm
#define ID_ccm MELF_mediam
#endif


#define MLOAD(name) load_mcode(ID_##name)
#endif

