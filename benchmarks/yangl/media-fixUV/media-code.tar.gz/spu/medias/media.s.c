/* Filename ： example.s.c
 * Author   :  shaolin.xie@ia.ac.cn
 * Description:  This is a example file to demostrate the 
 *               program of MaPU. 
 */

/* Include this file so that we can use the intrinsic funcitons */
#include <mspu-intrin.h> 
#include <mlib_mgr.h>
#include "common.h"

#define SDA0DM0_START 0x400000
#define SDA1DM0_START 0x800000
#define SDA2DM0_START 0xc00000

/*Declare the MPU function */
extern void srmh(void );
extern void srmv(void );
extern void init_parameter_sr(void );
extern void demh(void );
extern void demv(void );
extern void init_parameter_de(void );
extern void cem(void );
extern void ccm(void );
/*
uint32_t spu_send(uint32_t dst, uint32_t src, uint32_t width, uint32_t height,uint32_t size) 
{
  uint32_t ape_id = __mspu_getCh(0x1B);
  uint32_t bank_size = 0x1000;
  uint32_t bank_num = 64;
  if (size > 6) return -1;
  bank_num >>= size;
  size = 1 << size;
  bank_size *= size;
  src = src + ape_id * 0x1000000;
//  conf.DMAGlobalAddr = src;
  __mspu_setCh(CH_gAddr, src);

//  conf.DMAGlobalXNum = size * width;
  __mspu_setCh(CH_gXNum, size * width);

//  conf.DMAGlobalYAllNum = height;
  __mspu_setCh(CH_lAllNum, height);

//  conf.DMAGlobalYNum = bank_num;
  __mspu_setCh(CH_gYNum, bank_num);

//  conf.DMAGlobalYStep = size * width;
  __mspu_setCh(CH_gYStep, size * width);

//  conf.DMAGlobalZStep = size * width * bank_num;
  __mspu_setCh(CH_gZStep, size * width * bank_num);

//  conf.DMALocalAddr = dst;
  __mspu_setCh(CH_lAddr, dst);

//  conf.DMALocalXNum = size * width;
  __mspu_setCh(CH_lXNum, size * width);

//  conf.DMALocalYAllNum = height;
  __mspu_setCh(CH_lAllNum, height);

//  conf.DMALocalYNum = bank_num;
  __mspu_setCh(CH_lYNum, bank_num);

//  conf.DMALocalYStep = bank_size;
  __mspu_setCh(CH_lYStep, bank_size);

//  conf.DMALocalZStep = size * width;
  __mspu_setCh(CH_lZStep, size * width);

//  conf.DMAGroupNum = DATA_E2I_GP;
  __mspu_setCh(CH_DMAGrp, DATA_E2I_GP);

//  conf.DMACmd = CMD_EXT2INT;
  __mspu_setCh(CH_DMACmd, CMD_EXT2INT);

  return 0;
}
int spu_dma_wait()
{
  while (__mspu_getChNum(CH_DMACmd) < 8);

  __mspu_setCh(CH_DMAGrpMaskW, -1UL);
  __mspu_setCh(CH_DMAGrpStatU, 2);
  __mspu_getCh(CH_DMAGrpStat);
  return 0;
}
*/
int  main( int argc , char *argv[] )
{
  const int DataLength = 64;//length of vector
  const int StepH = 2;
  const int i = 0;
  
  int ki = 1200;
  int BIU[2][2];
  BIU[0][0]=0x400000;
  BIU[0][1]=0x600000;
  BIU[1][0]=0x800000;
  BIU[1][1]=0xA00000;

//////////////////////////////////UV COPY
//spu_send(BIU[1][i]+1280, BIU[0][i]+1304, 320, 120,DT_HALF);
//////////////////////////////////////////INIT
// BIU Configure, for BIU2
  __mspu_setKB(KB8, SDA2DM0_START+0x3EB00);
  __mspu_setKS(KS8, DataLength);
  __mspu_setKI(KI8, 21);
  __mspu_setKL(KL2, 1);
  __mspu_setKG(KG2, 6);
  MLOAD( init_parameter_de );
  __mspu_callmb( init_parameter_de );
  __mspu_setKE(KE2, 0);
  __mspu_setKE(KE5, 0);
  __mspu_setKE(KE6, 0);
/////////////////////////////////////////////////DE-H
  __mspu_setKI(KI12,320 );
  __mspu_setKI(KI13,4 );
// BIU Configure, for BIU0
  __mspu_setKB(KB0, BIU[0][i]);
  __mspu_setKS(KS0, StepH);
  __mspu_setKI(KI0, 1304);
  __mspu_setKL(KL0, 1);
  __mspu_setKG(KG0, 1);
// BIU Configure, for BIU2
  __mspu_setKB(KB8, SDA2DM0_START);
  __mspu_setKS(KS8, StepH);
  __mspu_setKI(KI8, 1280);
  __mspu_setKL(KL2, 1);
  __mspu_setKG(KG2, 1);
//Call the MPU program to compute the data
  MLOAD(demh);
  __mspu_callmb( demh );

//////////////////////////////////////////////////DE-V
  __mspu_setKI(KI12,120 );
  __mspu_setKI(KI13,10 );
// BIU Configure, for BIU0
  __mspu_setKB(KB0, BIU[0][i]+6);
  __mspu_setKS(KS0, 0x2000);
  __mspu_setKI(KI0, 32);
  __mspu_setKE(KE0, 28);

  __mspu_setKB(KB1, BIU[0][i]+6);
  __mspu_setKS(KS1, 652);
  __mspu_setKI(KI1, 3);

  __mspu_setKB(KB2, BIU[0][i]+6);
  __mspu_setKS(KS2, 64);
  __mspu_setKI(KI2, 10);

  __mspu_setKL(KL0, 3);
  __mspu_setKG(KG0, 6);
// BIU Configure, for BIU1
  __mspu_setKB(KB4, BIU[1][i]);
  __mspu_setKS(KS4, 0x2000);
  __mspu_setKI(KI4, 32);
  __mspu_setKE(KE4, 24);

  __mspu_setKB(KB5, BIU[1][i]);
  __mspu_setKS(KS5, 640);
  __mspu_setKI(KI5, 3);

  __mspu_setKB(KB6, BIU[1][i]);
  __mspu_setKS(KS6, 64);
  __mspu_setKI(KI6, 10);

  __mspu_setKL(KL1, 3);
  __mspu_setKG(KG1, 6);
// BIU Configure, for BIU2
  __mspu_setKB(KB8, SDA2DM0_START);
  __mspu_setKS(KS8, 0x2000);
  __mspu_setKI(KI8, 32);
  __mspu_setKE(KE8, 26);

  __mspu_setKB(KB9, SDA2DM0_START);
  __mspu_setKS(KS9, 640);
  __mspu_setKI(KI9, 3);

  __mspu_setKB(KB10, SDA2DM0_START);
  __mspu_setKS(KS10, 64);
  __mspu_setKI(KI10, 10);

  __mspu_setKL(KL2, 3);
  __mspu_setKG(KG2, 6);
//Call the MPU program to compute the data
  MLOAD(demv);
  __mspu_callmb( demv );
//  spu_dma_wait();

////////////////////////////////////////////////CE
  __mspu_setKI(KI12,ki );

// BIU Configure, for BIU0
  __mspu_setKB(KB0, BIU[0][i]);
  __mspu_setKS(KS0, 0xA00);
  __mspu_setKI(KI0, 3);
  __mspu_setKE(KE0, 0);

  __mspu_setKB(KB1, BIU[0][i]);
  __mspu_setKS(KS1, 64);
  __mspu_setKI(KI1, 10);

  __mspu_setKB(KB2, BIU[0][i]);
  __mspu_setKS(KS2, 0x2000);
  __mspu_setKI(KI2, 32);
  __mspu_setKE(KE2, 24);

  __mspu_setKB(KB3, BIU[0][i]);
  __mspu_setKS(KS3, 640);
  __mspu_setKI(KI3, 3);

  __mspu_setKL(KL0, 4);
  __mspu_setKG(KG0, 6);
// BIU Configure, for BIU1
  __mspu_setKB(KB4, BIU[1][i]);
  __mspu_setKS(KS4, 0xA00);
  __mspu_setKI(KI4, 3);
  __mspu_setKE(KE4, 0);

  __mspu_setKB(KB5, BIU[1][i]);
  __mspu_setKS(KS5, 64);
  __mspu_setKI(KI5, 10);

  __mspu_setKB(KB6, BIU[1][i]);
  __mspu_setKS(KS6, 0x2000);
  __mspu_setKI(KI6, 32);
  __mspu_setKE(KE6, 24);

  __mspu_setKB(KB7, BIU[1][i]);
  __mspu_setKS(KS7, 640);
  __mspu_setKI(KI7, 3);

  __mspu_setKL(KL1, 4);
  __mspu_setKG(KG1, 6);  

// BIU Configure, for BIU2
  __mspu_setKB(KB8, SDA2DM0_START+0x3F040);
  __mspu_setKS(KS8, DataLength);
  __mspu_setKI(KI8, 43);
  __mspu_setKE(KE8, 0);

  __mspu_setKL(KL2, 1);
  __mspu_setKG(KG2, 6);

  MLOAD(cem);
  __mspu_callmb( cem );

/////////////////////////////////////////////CC
  __mspu_setKI(KI12,ki );

// BIU Configure, for BIU0
  __mspu_setKB(KB0, BIU[0][i]);
  __mspu_setKS(KS0, 0xA00);
  __mspu_setKI(KI0, 3);

  __mspu_setKB(KB1, BIU[0][i]);
  __mspu_setKS(KS1, 64);
  __mspu_setKI(KI1, 10);

  __mspu_setKB(KB2, BIU[0][i]);
  __mspu_setKS(KS2, 0x2000);
  __mspu_setKI(KI2, 32);
  __mspu_setKE(KE2, 24);

  __mspu_setKB(KB3, BIU[0][i]);
  __mspu_setKS(KS3, 640);
  __mspu_setKI(KI3, 3);

  __mspu_setKL(KL0, 4);
  __mspu_setKG(KG0, 6);
// BIU Configure, for BIU1
  __mspu_setKB(KB4, BIU[1][i]);
  __mspu_setKS(KS4, 64);
  __mspu_setKI(KI4, 20);

  __mspu_setKB(KB5, BIU[1][i]);
  __mspu_setKS(KS5, 0x2000);
  __mspu_setKI(KI5, 32);
  __mspu_setKE(KE5, 24);

  __mspu_setKB(KB6, BIU[1][i]);
  __mspu_setKS(KS6, 1280);
  __mspu_setKI(KI6, 3);
  __mspu_setKE(KE6, 0);

  __mspu_setKL(KL1, 3);
  __mspu_setKG(KG1, 6);  


// BIU Configure, for BIU2
  __mspu_setKB(KB8, SDA2DM0_START+0x3FB00);
  __mspu_setKS(KS8, DataLength);
  __mspu_setKI(KI8, 20);
  __mspu_setKL(KL2, 1);
  __mspu_setKG(KG2, 6);

//Call the MPU program to compute the data
  MLOAD(ccm);
  __mspu_callmb( ccm );

  return 0;
}
